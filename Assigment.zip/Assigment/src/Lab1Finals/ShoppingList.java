package Lab1Finals;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class ShoppingList {
    private List<ShoppingListItem> items;

    ShoppingList() {
        this.items = new ArrayList<>();
    }

    void addItem(String itemName, String itemDescription, double itemPrice) {
        ShoppingListItem newItem = new ShoppingListItem(itemName, itemDescription, itemPrice);
        items.add(newItem);
    }

    void removeItem(int index) {
        if (index >= 0 && index < items.size()) {
            ShoppingListItem removedItem = items.remove(index);
            System.out.println("Removed item [" + (index + 1) + "] " + removedItem.itemName + " from the list.");
        } else {
            System.out.println("Invalid index. Item not removed.");
        }
    }

    void markItemAsPurchased(int index) {
        if (index >= 0 && index < items.size()) {
            ShoppingListItem item = items.get(index);
            System.out.println("Marked item [" + (index + 1) + "] " + item.itemName + " as purchased.");
            // You can add logic here to update the item's status.
        } else {
            System.out.println("Invalid index. Item not marked as purchased.");
        }
    }

    void displayList() {
        if (items.isEmpty()) {
            System.out.println("Shopping List is empty.");
        } else {
            System.out.println("\nMy Shopping List:");
            System.out.printf("%-30s | %-40s | %s%n", "Item name", "Item Description", "Price");
            for (int i = 0; i < items.size(); i++) {
                ShoppingListItem item = items.get(i);
                System.out.printf("[%d] %-26s | %-38s | P%.2f%n", (i + 1), item.itemName, item.itemDescription, item.itemPrice);
            }
        }
    }

    void saveListToFile() {
        if (items.isEmpty()) {
            System.out.println("Shopping List is empty. Nothing to save.");
            return;
        }

        try {
            FileWriter fileWriter = new FileWriter("D:\\Desktop\\myFiles\\College\\2nd year college\\1st Term\\Data Structures & Algorithms\\Programming\\Assigment.txt");
            fileWriter.write("My Shopping List:\n");
            fileWriter.write(String.format("%-30s | %-40s | %s%n", "Item name", "Item Description", "Price"));

            for (int i = 0; i < items.size(); i++) {
                ShoppingListItem item = items.get(i);
                fileWriter.write(String.format("[%d] %-26s | %-38s | ₱%.2f%n", (i + 1), item.itemName, item.itemDescription, item.itemPrice));
            }

            fileWriter.close();
            System.out.println("\nShopping List saved to file successfully.");
        } catch (IOException e) {
            System.out.println("\nAn error occurred while saving the Shopping List to a file.");
        }
    }
}