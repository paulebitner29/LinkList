package Lab1Finals;
class ShoppingListItem {
    String itemName;
    String itemDescription;
    double itemPrice;

    public ShoppingListItem(String itemName, String itemDescription, double itemPrice) {
        this.itemName = itemName;
        this.itemDescription = itemDescription;
        this.itemPrice = itemPrice;
    }
}