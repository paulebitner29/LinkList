package Lab1Finals;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ShoppingList myShoppingList = new ShoppingList();

        while (true) {
        	System.out.println("---- My Shopping List ----");
            System.out.println("1. Add Item");
            System.out.println("2. Remove Item");
            System.out.println("3. Mark Item as Purchased");
            System.out.println("4. Display List");
            System.out.println("5. Save List to File");
            System.out.println("6. Exit");
            System.out.println("--------------------------");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter item name: ");
                    String itemName = scanner.nextLine();
                    System.out.print("Enter item description: ");
                    String itemDescription = scanner.nextLine();
                    System.out.print("Enter item price: ");
                    double itemPrice = scanner.nextDouble();
                    scanner.nextLine(); // Consume the newline character
                    myShoppingList.addItem(itemName, itemDescription, itemPrice);
                    break;
                case 2:
                    myShoppingList.displayList();
                    System.out.print("Enter the index of the item to remove: ");
                    int removeIndex = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline character
                    myShoppingList.removeItem(removeIndex - 1); // Adjust index to 0-based
                    break;
                case 3:
                    myShoppingList.displayList();
                    System.out.print("Enter the index of the item to mark as purchased: ");
                    int markIndex = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline character
                    myShoppingList.markItemAsPurchased(markIndex - 1); // Adjust index to 0-based
                    break;
                case 4:
                    myShoppingList.displayList();
                    break;
                case 5:
                    myShoppingList.saveListToFile();
                    break;
                case 6:
                    System.out.println("\nExiting program.");
                    System.exit(0);
                    break;
                default:
                    System.out.println("\nInvalid choice. Please try again.");
            }
        }
    }
}